// sound.h


int get_sound();