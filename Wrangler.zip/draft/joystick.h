// joystick.h

int get_joystick();
