//  DCmotor.h


void init_motor_6612();
void run(int dir);
