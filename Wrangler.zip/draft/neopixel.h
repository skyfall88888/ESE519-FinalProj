// neopixel.h

#include <stdio.h>
#include <stdlib.h>

void neopixel_init();
void neopixel_set_rgb(uint32_t rgb);
